from pathlib import Path
import subprocess,json,hashlib,sys
import numpy as np
r=Path(__file__).parent
sys.path.insert(0,'/Users/tangenjie/Downloads/mvs-matrix-vfx-1009/server/scripts')
from manhua_vfx_liquid_ghost import roi_mask
ff='/opt/homebrew/bin/ffmpeg'
fp='/opt/homebrew/bin/ffprobe'
spec=json.loads((r/'spec.json').read_text())
size=360*640*3
def decode(name):
    raw=subprocess.check_output([ff,'-v','error','-threads','2','-i',str(r/name),'-map','0:v:0','-an','-pix_fmt','rgb24','-f','rawvideo','pipe:1'])
    assert len(raw)%size==0
    frames=np.frombuffer(raw,np.uint8).reshape(-1,640,360,3)
    assert len(frames)==96 and np.all(frames.reshape(96,-1).std(axis=1)>1)
    return frames,raw
source,_=decode('source.mp4')
processed,raw=decode('processed.mkv')
final,_=decode('新特效一次探针.mp4')
receipt=json.loads((r/'processed.mkv.json').read_text())
assert hashlib.sha256(raw).hexdigest()==receipt['decodedOutputSha256']
counts=np.count_nonzero(np.any(processed!=source,axis=-1),axis=(1,2))
effects=[]
for effect in spec['effects']:
    indices=[i for i in range(96) if effect['startSec']<=i/24<effect['startSec']+effect['durationSec']]
    assert len(indices)>0 and all(counts[i]>0 for i in indices)
    row=dict(kind=effect['kind'],frames=indices,changedPixels=[int(counts[i]) for i in indices])
    if effect['kind']=='mirror_corridor':
        for i in indices:
            outside=roi_mask(effect,i/24,360,640)==0
            assert np.array_equal(source[i][outside],processed[i][outside])
        row['roiOutsideExactlyPreserved']=True
    effects.append(row)
inactive=[i for i in range(96) if not any(e['startSec']<=i/24<e['startSec']+e['durationSec'] for e in spec['effects'])]
assert all(counts[i]==0 for i in inactive)
def audio(name):
    return subprocess.check_output([ff,'-v','error','-i',str(r/name),'-map','0:a:0','-c','copy','-f','data','pipe:1'])
a=audio('source.mp4'); b=audio('新特效一次探针.mp4')
assert len(a)>0 and a==b
probe=json.loads(subprocess.check_output([fp,'-v','error','-show_streams','-show_format','-of','json',str(r/'新特效一次探针.mp4')],text=True))
for name,sec in [('镜面-原片',1),('镜面-结果',1),('纸页-原片',2.8),('纸页-结果',2.8)]:
    target=r/(name+'.png')
    video=r/('source.mp4' if name.endswith('原片') else '新特效一次探针.mp4')
    subprocess.run([ff,'-v','error','-n','-ss',str(sec),'-i',str(video),'-frames:v','1',str(target)],check=True)
summary=dict(id='DEV_PROBE_PR1694_ONCE_1009',sourceHead='7c716985384aa294bd2c534775d9aee53d90379c',frames=96,decodedNonemptyFrames=96,processedSha256MatchesReceipt=True,inactiveFramesExactlyPreserved=inactive,effects=effects,audio=dict(bytes=len(a),sha256=hashlib.sha256(a).hexdigest(),exactPacketBytesEqual=True),video=dict(path=str(r/'新特效一次探针.mp4'),bytes=(r/'新特效一次探针.mp4').stat().st_size,sha256=hashlib.sha256((r/'新特效一次探针.mp4').read_bytes()).hexdigest(),duration=probe['format']['duration'],codec=probe['streams'][0]['codec_name'],width=360,height=640,fps=24),normalSpeedHumanReview='未验证',productionWorkflow='尚未线上验收',modelCalls=0,cost=0)
(r/'qa-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
(r/'index.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>PR1694一次开发探针</title><style>body{background:#fcf7ef;color:#29241f;font:17px system-ui;margin:30px}video{max-height:80vh;max-width:100%}p{max-width:750px;line-height:1.6}</style><h1>镜面纵深与纸页悬浮：一次开发探针</h1><p>版本7c716985 · DEV_PROBE_PR1694_ONCE_1009 · 原片12–16秒 · 费用0。0.2–1.8秒镜面，2.0–3.8秒纸页。机器检查96帧非空、窗外原像素与镜面ROI外保持、原声AAC逐字节相同；未做正式线上验收或人工常速质量确认。</p><video controls playsinline src="新特效一次探针.mp4"></video><p>两个效果都是二维处理。镜面不是三维重建；纸页不改变人物重力或计算遮挡。</p></html>')
print(json.dumps({k:summary[k] for k in ['id','frames','decodedNonemptyFrames','audio','video','normalSpeedHumanReview','productionWorkflow','modelCalls','cost']},ensure_ascii=False))
