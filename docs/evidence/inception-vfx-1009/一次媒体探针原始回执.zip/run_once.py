from pathlib import Path
import subprocess,json,os,time
r=Path(__file__).parent
repo=Path('/Users/tangenjie/Downloads/mvs-matrix-vfx-1009')
b='/Applications/Blender.app/Contents/MacOS/Blender'
env=dict(os.environ,PATH='/opt/homebrew/bin:'+os.environ.get('PATH',''))
receipt={'id':'DEV_PROBE_PR1694_ONCE_1009','sourceHead':'7c716985384aa294bd2c534775d9aee53d90379c','steps':[],'modelCalls':0,'cost':0}
def run(label,args):
    start=time.monotonic()
    print('START '+label,flush=True)
    with (r/(label+'.log')).open('x') as out: result=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
    row=dict(step=label,exit=result.returncode,elapsedSec=round(time.monotonic()-start,3))
    receipt['steps'].append(row)
    (r/'probe-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
    print(json.dumps(row,ensure_ascii=False),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
base=[b,'--background','--factory-startup','--disable-autoexec','--threads','2','--python-exit-code','1','--python']
run('source-pixels',base+[str(repo/'server/scripts/manhua_vfx_liquid_ghost.py'),'--',str(r/'spec.json'),str(r/'source.mp4'),str(r/'processed.mkv')])
run('transparent-layers',base+[str(repo/'server/scripts/manhua_vfx.py'),'--',str(r/'spec.json'),str(r/'layers')])
run('composite',['/opt/homebrew/bin/ffmpeg','-nostdin','-hide_banner','-loglevel','error','-n','-i',str(r/'processed.mkv'),'-framerate','24','-i',str(r/'layers/frame-%06d.png'),'-i',str(r/'source.mp4'),'-filter_complex','[0:v][1:v]overlay=alpha=straight:eof_action=pass:repeatlast=0[v]','-map','[v]','-map','2:a:0?','-t','4','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-crf','18','-c:a','copy','-movflags','+faststart',str(r/'新特效一次探针.mp4')])
receipt['video']=str(r/'新特效一次探针.mp4')
receipt['bytes']=(r/'新特效一次探针.mp4').stat().st_size
receipt['completed']=True
(r/'probe-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
print('OUTPUT '+receipt['video'],flush=True)
