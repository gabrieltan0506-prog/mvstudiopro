from pathlib import Path
import subprocess,time,json
r=Path('/Users/tangenjie/Downloads/2026Oct09/特效探针Demo/PR1694-三维碎裂与定格');repo=Path('/Users/tangenjie/Downloads/mvs-matrix-vfx-1009');rows=[]
steps=[('overlay-v2',['blender','-b','--factory-startup','--disable-autoexec','-t','2','--python-exit-code','1','--python',str(repo/'server/scripts/manhua_vfx.py'),'--',str(r/'overlay-v2.json'),str(r/'overlay-v2-frames')]),('compose-v2',['ffmpeg','-v','error','-n','-i',str(r/'source.mp4'),'-framerate','24','-i',str(r/'overlay-v2-frames/frame-%06d.png'),'-framerate','24','-i',str(r/'city-frames/frame-%06d.png'),'-filter_complex','[0:v][1:v]overlay=shortest=1[a];[a][2:v]overlay=shortest=1,format=yuv420p[v]','-map','[v]','-map','0:a?','-c:v','libx264','-threads','2','-crf','18','-c:a','copy','-movflags','+faststart',str(r/'咖啡杯果摊连爆与街区翻折-v2.mp4')])]
for name,args in steps:
 t=time.monotonic()
 with (r/(name+'.log')).open('w') as f:result=subprocess.run(args,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'stage':name,'exit':result.returncode,'seconds':round(time.monotonic()-t,3),'command':args});(r/'修正回执-v2.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
