import {readFileSync,writeFileSync} from 'node:fs';
import {validateVfxManifest,validateVfxWorldManifest} from '/Users/tangenjie/Downloads/mvs-matrix-vfx-1009/server/services/manhuaVfxRender.ts';
const root='/Users/tangenjie/Downloads/2026Oct09/特效探针Demo/PR1694-三维碎裂与定格';
const read=(p:string)=>JSON.parse(readFileSync(root+'/'+p,'utf8'));
const rows=[];
for(const name of ['overlay','overlay-v2','city','world']){
 const spec=read(name+'.json'),manifest=read(name+'-frames/manifest.json');
 const parsed=name==='world'?validateVfxWorldManifest(manifest,spec.effects[0],spec):validateVfxManifest(manifest,spec,spec);
 rows.push({name,frames:parsed.frames.length,complete:parsed.complete,gate:'production-manifest-validator'});
}
writeFileSync(root+'/实际服务端门禁回执.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
