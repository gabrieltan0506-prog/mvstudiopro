from pathlib import Path
import subprocess,json,time,hashlib
root=Path('/Users/tangenjie/Downloads/2026Oct09/特效探针Demo/PR1694-三维碎裂与定格')
repo=Path('/Users/tangenjie/Downloads/mvs-matrix-vfx-1009');rows=[]
def run(name,args):
 start=time.monotonic()
 with (root/(name+'.log')).open('w') as out:r=subprocess.run(args,cwd=repo,stdout=out,stderr=subprocess.STDOUT)
 rows.append({'stage':name,'exit':r.returncode,'seconds':round(time.monotonic()-start,3),'command':args});(root/'执行回执.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('source',['ffmpeg','-v','error','-n','-ss','12','-i','/Users/tangenjie/Downloads/2026Oct03/墨菁傳第一集.mp4','-t','8','-vf','scale=360:640,fps=24','-c:v','libx264','-threads','2','-pix_fmt','yuv420p','-c:a','aac',str(root/'source.mp4')])
for name in ['overlay','city','world']:
 script=repo/'server/scripts'/('manhua_vfx_world_props.py' if name=='world' else 'manhua_vfx.py')
 run(name,['blender','-b','--factory-startup','--disable-autoexec','-t','2','--python-exit-code','1','--python',str(script),'--',str(root/(name+'.json'))]+(['world-probe'] if name=='world' else [])+[str(root/(name+'-frames'))])
run('compose',['ffmpeg','-v','error','-n','-i',str(root/'source.mp4'),'-framerate','24','-i',str(root/'overlay-frames/frame-%06d.png'),'-framerate','24','-i',str(root/'city-frames/frame-%06d.png'),'-filter_complex','[0:v][1:v]overlay=shortest=1[a];[a][2:v]overlay=shortest=1,format=yuv420p[v]','-map','[v]','-map','0:a?','-c:v','libx264','-threads','2','-crf','18','-c:a','copy','-movflags','+faststart',str(root/'咖啡杯果摊连爆与街区翻折.mp4')])
run('world-encode',['ffmpeg','-v','error','-n','-framerate','24','-i',str(root/'world-frames/frame-%06d.png'),'-c:v','libx264','-threads','2','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(root/'碎片定格人物活动-TEST_ONLY.mp4')])
print('ALL_DONE',flush=True)
