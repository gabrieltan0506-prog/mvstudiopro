import sys,json
sys.path.insert(0,'/Users/tangenjie/Downloads/mvs-matrix-vfx-1009/server/scripts')
import bpy
from manhua_vfx_world_props import prepare_world_scene,update_world_scene,preflight_hold
p='/Users/tangenjie/Downloads/2026Oct08/PR1685-正式路径四秒扶坐小样/原始产物/artifacts/post-prod/7/previs/33333333-3333-4333-8333-333333331009/scene.blend'
bpy.ops.wm.open_mainfile(filepath=p)
spec={'version':1,'seed':1009,'durationSec':4,'fps':24,'width':360,'height':640}
e={'id':'world-probe','kind':'prop_scene','startSec':0,'durationSec':4,'color':'#F3E8D4','scale':1,'intensity':1,'anchor':{'space':'screen','position':[.5,.5]},'prop':{'impactSec':.25,'spread':1.1,'slowMotion':.18,'gravity':.8,'staggerSec':.1,'holdStartSec':.8,'holdDurationSec':1.8},'world':{'sourceStartSec':0,'propKind':'fruit_stall_fracture','position':[0,0,1],'yawDeg':0,'size':.6}}
prop={k:v for k,v in e.items() if k!='world'};prop['kind']=e['world']['propKind'];spec['effects']=[e]
s=bpy.context.scene;h=prepare_world_scene(s,e,prop,spec)
r=preflight_hold(s,h,e,prop,spec)
rows=[]
for t in [0,.5,.8,1.2,1.8,2.5,3.5]:
 proof=update_world_scene(s,h,e,prop,spec,t);rows.append({'time':t,**proof})
print('WORLD_RUNTIME '+json.dumps({'mediaRendered':False,'source':'TEST_ONLY扶坐四秒','preflight':r,'rows':rows,'cameraMatrix':[list(row) for row in s.camera.matrix_world],'actorBounds':{o.name:{'location':list(o.matrix_world.translation),'dimensions':list(o.dimensions)} for o in h['actors']}},ensure_ascii=False))
# 负向：真实静态帧不能通过人物活动预检。
for o in s.objects:
 if o.animation_data:o.animation_data_clear()
try:preflight_hold(s,h,e,prop,spec)
except ValueError as error:print('STATIC_REJECTED '+str(error))
else:raise AssertionError('静态人物未被拦截')
