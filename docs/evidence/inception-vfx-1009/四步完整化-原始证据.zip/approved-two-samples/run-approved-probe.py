import sys,json,hashlib,copy
from pathlib import Path
import bpy
sys.path.insert(0,'/Users/tangenjie/Downloads/mvs-matrix-vfx-1009/server/scripts')
from manhua_vfx_world_props import prepare_world_scene,update_world_scene,preflight_hold
from manhua_vfx_world_layers import render_world_layers
root=Path(__file__).resolve().parent
spec=json.loads((root/'input.json').read_text());event=spec['effects'][0]
assert hashlib.sha256(Path(event['scenePath']).read_bytes()).hexdigest()==event['sceneSha256']
prop=copy.deepcopy(event);prop.pop('world');prop['kind']=event['world']['propKind']
manifest={'scope':'TEST_ONLY已批准两时点分层探针，非连续动画/正式验收','complete':False,'sampleTimes':[.9,1.2],
 'eventId':event['id'],'sceneJobId':event['world']['sceneJobId'],'sceneSha256':event['sceneSha256'],
 'width':360,'height':640,'files':[],'frames':[],'separated':{'version':1,'complete':False,'bytes':0,'depthEncoding':'linear_z_pass_clip_normalized_u16','frames':[]}}
def save(): (root/'probe-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
save()
try:
 bpy.ops.wm.open_mainfile(filepath=event['scenePath']);scene=bpy.context.scene
 handle=prepare_world_scene(scene,event,prop,spec)
 # 本次用户只批准两个时点，完整4秒另有第52帧净空阻断，保留原报告，不宣称整段通过。
 sampled=[update_world_scene(scene,handle,event,prop,spec,t) for t in manifest['sampleTimes']]
 if any(not q['active'] or not q['held'] or q['clearance']['issues'] for q in sampled):raise ValueError('批准的两时点净空/定格未通过')
 if len({q['worldPropSha256'] for q in sampled})!=1:raise ValueError('两时点碎片世界几何未冻结')
 if len({q['actorPoseSha256'] for q in sampled})!=2:raise ValueError('两时点原人物未活动')
 manifest['sampledPreflight']={'times':manifest['sampleTimes'],'complete':True,'proofs':sampled,'fullFourSecondAcceptance':False,'fullSequenceBlock':'第52帧保守净空不足，禁止当作完整动画验收'}
 manifest['lighting']=handle['lighting'];manifest['blenderVersion']=bpy.app.version_string;save()
 for frame,time in enumerate(manifest['sampleTimes'],1):
  proof=update_world_scene(scene,handle,event,prop,spec,time)
  if proof.get('clearance',{}).get('issues'):raise ValueError('批准时点真实网格净空未通过，未开始本帧渲染')
  target=root/('frame-%06d.png'%frame)
  if target.exists():raise ValueError('禁止覆盖已有本次探针图像')
  scene.render.filepath=str(target);bpy.ops.render.render(write_still=True)
  raw=target.read_bytes();manifest['files'].append({'frame':frame,'path':target.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
  manifest['frames'].append({'frame':frame,'timeSec':time,'effects':[proof]});save()
  layers=render_world_layers(scene,handle,root,frame,True)
  manifest['separated']['frames'].append(layers);manifest['separated']['bytes']+=sum(f['bytes'] for f in layers['files']);save()
 manifest['separated']['complete']=True;manifest['complete']=True;save();print('APPROVED_TWO_FRAME_PROBE_COMPLETE',flush=True)
except Exception as error:
 manifest['error']=str(error);save();raise
