import sys, json, hashlib
sys.path.insert(0, '/Users/tangenjie/Downloads/mvs-matrix-vfx-1009/server/scripts')
import bpy
import numpy as np
from manhua_vfx import configure_scene, build_vfx, update_vfx
from manhua_vfx_dream_pixels_test import effect, spec
from manhua_vfx_liquid_ghost import PixelProcessor
out=[]
y,x=np.indices((120,160))
frame=np.stack([x*1.5,y*2,(x+y)%230],axis=-1).astype(np.uint8)
for kind in ('mirror_corridor','floating_paper'):
    recipe=spec(effect(kind))
    scene=configure_scene(recipe)
    handles=build_vfx(recipe,scene)
    states=update_vfx(handles,recipe,.75)
    assert len(states)==1 and states[0]['mode']=='source-pixels-before-overlay', states
    processor=PixelProcessor(recipe)
    processor.index=18
    result=processor.process(frame)
    changed=int(np.count_nonzero(np.any(result!=frame,axis=-1)))
    assert changed>0
    out.append(dict(kind=kind,changedPixels=changed,sha256=hashlib.sha256(result.tobytes()).hexdigest(),mode=states[0]['mode']))
print('RUNTIME_PROBE='+json.dumps(dict(blender=bpy.app.version_string,numpy=np.__version__,results=out,renderedFiles=0),ensure_ascii=False))
